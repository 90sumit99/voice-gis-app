const map = L.map('map').setView([20.5937, 78.9629], 5); // Centered on India

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);


function handleVoiceCommand(command) {
    console.log(`Command received: ${command}`);
    if (command.includes('zoom in')) {
      map.zoomIn();
    } else if (command.includes('zoom out')) {
      map.zoomOut();
    } else if (command.includes('show roads')) {
      // Example of toggling a layer
      if (!roadsLayer) {
        roadsLayer = L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png');
      }
      if (!map.hasLayer(roadsLayer)) {
        map.addLayer(roadsLayer);
      } else {
        map.removeLayer(roadsLayer);
      }
    } else if (command.includes('go to') || command.includes('navigate to')) {
      const location = command.split('to')[1].trim();
      // Use a geocoding service to get coordinates
      // This is a placeholder for actual geocoding implementation
      goToLocation(location);
    }
  }
  
  function goToLocation(location) {
    // Placeholder function
    console.log(`Navigating to ${location}`);
    // Implement geocoding API call to get coordinates and set view
  }
  